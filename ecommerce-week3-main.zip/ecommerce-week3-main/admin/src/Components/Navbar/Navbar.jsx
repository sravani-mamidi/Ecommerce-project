import React from 'react'
import './Navbar.css'
// import navlogo from '../Assets/nav-logo.svg'
// import navprofileIcon from '../Assets/nav-profile.svg'

const Navbar = () => {
  return (
    <div className='navbar'>
 
      <div>Fashion Club Admin/Seller Panel</div>
    </div>
  )
}

export default Navbar
